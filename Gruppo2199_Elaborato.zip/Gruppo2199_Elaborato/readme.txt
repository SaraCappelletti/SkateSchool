Il database è di tipo SQLServer, l'applicazione è stata sviluppata su VisualStudio 2022.

Per farla partire basta eseguire il file SkateSchool.exe

Se si desidera creare il database da zero per prima cosa bisogna eseguire lo script per generare il databse (1CreateDatabase.sql), poi quello per le tabelle (2CreateTables.ddl) ed infine quello per riempire le tabelle (3InsertData.sql).
Infine eseguire il file SkateSchool.exe